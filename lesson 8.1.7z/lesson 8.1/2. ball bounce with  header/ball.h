void FillCircle( SDL_Window *window ,SDL_Renderer *renderer,int r,int a,int b)
{  int i=0;
   int j=0;
   int h;
   for(i=-r ; i< r; ++i)
    {  h = sqrt(r*r - i*i);
       for(j=-h ; j< h; ++j)
            {
             SDL_RenderDrawPoint(renderer ,i+a,j+b);
            }
        }
SDL_RenderPresent(renderer);
}

void ball(SDL_Window *window ,SDL_Renderer *renderer){

	SDL_Event eve;
	bool quit = false;
    int p, x,y=400,l=25,z = 1 ;

    while (!quit){
        SDL_PollEvent(&eve);
        if(eve.type == SDL_QUIT)
        {
            quit = true;
        }
                    --l;
                    x=l;
                    while(x>0){
                       
                        y=y-x;
                        x--;
                        z= z+2;
                        SDL_SetRenderDrawColor(renderer, 0,255,0,255);
                        SDL_RenderClear(renderer);
                        SDL_SetRenderDrawColor(renderer, 255,255,255,255);
                        FillCircle(window, renderer , 30, z,y);
                      
                        p=y;
                      SDL_Delay(10);
                }
                x=0;
                y=p;
                while(y<400){
                    z=z+2;
                   
                    y=y+x;
                    x++;
                    SDL_SetRenderDrawColor(renderer, 0,255,0,255);
                    SDL_RenderClear(renderer);
                    SDL_SetRenderDrawColor(renderer, 255,255,255,255);
                    FillCircle(window, renderer , 30, z,y);
                  
                    SDL_Delay(10);
                            }
}
}