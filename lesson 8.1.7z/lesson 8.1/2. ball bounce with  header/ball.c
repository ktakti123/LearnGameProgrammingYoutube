

#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "math.h"
#include<stdbool.h>
#include <E:/cgame/codes/ball.h>


int main(int argc, char* argv[])
{   
    
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window *window = SDL_CreateWindow("hello",SDL_WINDOWPOS_CENTERED,
    SDL_WINDOWPOS_CENTERED,640,480,0);
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1 , 0);
    SDL_SetRenderDrawColor(renderer, 0,255,0,255);
    SDL_RenderClear(renderer);
    SDL_RenderPresent(renderer);
    SDL_SetRenderDrawColor(renderer, 255,255,255,255);
    ball(window,renderer);


SDL_DestroyWindow(window);
SDL_DestroyRenderer(renderer);
SDL_Quit();
return 0;
}
